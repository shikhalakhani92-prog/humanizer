---
name: voice-profile-shikha
person: Shikha
---
# Voice profile: Shikha

## Who writes and who reads
Shikha writes for two worlds: recruiters, hiring managers and her professional network, and followers on LinkedIn, Substack and X. Her voice differs sharply between them, so there are three archetypes.

## Archetypes

### Professional
- Use for: recruiters, hiring managers, networking, cover letters, CV bullets, corporate work messages.
- Tone and register: crisp, confident, warm, formal. Plain verbs, complete natural sentences.
- Voice markers to keep: answer or ask first. One specific reason for writing, from the source. One ask. Ownership ("I'll send the CV", not "the CV will be provided"). Warmth said plainly, once.
- Never: stock phrases ("persevered", "aspire, strive and deliver"), inflated claims, invented achievements.
- Sentence rhythm: mostly 12 to 25 words. Fragments sparingly. No one-word sentences. And/But/So openers light.
- Imperfection: clean spelling and grammar. None.
- Length: follows the input, within about 15%.
- Closers and hashtags: one clear ask or a plain thank-you. No hashtags.
- Real sample: none written without AI. Her application essay (about Create Out) is weak evidence only: plain statements like "I hastily took on board 20 artists" are good, the stock phrases are not.
- Status: to be refined (no real sample yet). Ask her for one real recruiter or networking message and tighten this block.
- CV bullets: every number exact, verbs everyday, no inflation.
- Contractions by default. Drop them only in formal documents.

### Observational
- Use for: LinkedIn posts, Substack, blog.
- Tone and register: warm, conversational, anecdote-led, a gentle opinion. Casual.
- Voice markers to keep: starts from something she saw (a store sign, a booking screen, her dad's knotted bags), gives a short take, lands a gentle opinion. Specific local detail ("chaos control cafe", "her 'magician'"). Sharpest when she says plainly what would not work on her and why (the Google Pay post).
- Never: generic closers, motivational-poster morals, invented anecdotes.
- Sentence rhythm: mixed, 1 to 30 words, real variation. One crafted line at most.
- Imperfection: light. Casual punctuation. ":)" or "!!" sparingly and only where the source already has them. Lowercase starts only if the source already does them. Never plant typos.
- Length: LinkedIn 80 to 200 words. Substack 600 to 1,200 words.
- Closers and hashtags: ends on one specific, real question to the reader, or a small moral. Not both. Her own hashtags are kept (usually 2 to 4). If she asks for hashtags, add at most 3.
- Real samples (her LinkedIn posts):
  - "Passing by a Carrefour with no requirement to shop on the given day and all that stood out was the "chocolate factory" signboard and colourful factory like piping decor."
  - "Any other brands that do this well off the digital communication methods?"
  - "Confidence is good but to be humble knowing how it's not all "us" is good to remember."
- Status: grounded.

### Aphoristic
- Use for: X posts, short punchy takes.
- Tone and register: sharp, opinionated, casual, a little cheek. Light observational humour.
- Voice markers to keep: one idea in one or two sentences. Reframes a common word ("stuck", "fear", "motivation"). Compressed frameworks, such as a single arrow chain. Casual grammar ("ain't") where her voice carries it.
- Never: padding, explanation of the joke, hashtag piles.
- Sentence rhythm: mostly under 15 words.
- Imperfection: light. Full imitation (dropped letters, run-ons) only when she asks.
- Length: under 280 characters.
- Closers and hashtags: usually none. A real question is fine ("is it okay to not have one yet?").
- Real samples (her tweets):
  - "Often we say we are "stuck" but we mean in the given situation we ain't sure if we are willing to pay the price for what we desire."
  - "The only people that you need to make proud - the 8year old version of you and the 80year old version of you"
  - "While everyone's got a opinion on twitter and Elon, is it okay to not have one yet?"
- Status: grounded (samples are from 2022, confirmed still her voice).
- The "one crafted line" limit does not apply. The post can be one crafted line. Idiom limit relaxed.

## Spelling and dialect
British spelling. Keep Indian-English phrasing and cultural references as they are (jugaad, "basis", names, places). Do not smooth them into neutral global English.

## Stretch targets
A Medium piece on fragrances that she admires (not hers, not to copy line for line). Moves to borrow for Substack, only with material from her source or interview: a hook, a pop-culture anchor that frames the argument and pays off at the end, a real thesis (an idea, not a description), a short deflating line after a long build, self-implication at the close.

## Never touch or invent
Facts, numbers, names, quotes. Flag confidential former-employer details (internal figures, named internal programmes) in the change notes in Professional pieces. Do not remove them yourself.

## Personal bans and allowances
- Semicolons: banned in Observational and Aphoristic, a soft flag in Professional.
- Idiom limit relaxed in Aphoristic.
- "journey", "ecosystem" and "landscape" are not banned for her. They are soft flags: keep them when they are the ordinary term (customer journey, competitive landscape, marketplace ecosystem), cut them when decorative.
- Her own past writing uses words like "journey" and "moat". The ban list applies to the output only.

## HARD WORDS
# none beyond tells.md

## HARD PHRASES
# none beyond tells.md

## SOFT WORDS
# none beyond tells.md

## ALLOW
# none

## CHECKER
global: dashes=hard
archetype: professional | semicolons=soft | band=12-25 | band_share=0.6 | one_word=no | contractions=expect
archetype: observational | semicolons=hard | max_sentence=30 | burstiness=0.45 | contractions=expect
archetype: aphoristic | semicolons=hard | short_under=15 | short_share=0.7 | max_chars=280 | contractions=expect
