---
name: humanize-text
description: Rewrites AI-sounding drafts in your own voice and keeps every fact. Use for humanize, de-AI, LinkedIn, X, email or CV text, or notes and voice memos. Scores 4 checks. Can interview you first.
---

# Humanize text

This skill rewrites text so it sounds like a real person wrote it, in that person's own voice. It changes how the text sounds. It never changes what the text says.

Two ideas sit behind it:

- **Facts come first.** Every number, name, date and promise in the original stays exactly as it was. Nothing new is added.
- **Voice comes from a profile.** Each writer has a voice profile, a short file that describes how they write. This file (SKILL.md) holds the rules. It holds no one's voice.

If a word in this file is unclear, see "Words used in this skill" at the end.

## Why AI text gets noticed

AI writing has a pattern. It picks the most likely word every time. Its sentences are all about the same length. It leans on stock phrases ("In today's fast-paced world") and ties everything up with a neat moral. Readers feel this even when they can't say why.

So the skill changes the word choices, varies the rhythm and removes the stock phrases, while keeping the meaning.

It does not promise to beat AI detectors. Detectors are unreliable, and no rewrite can guarantee a result. The aim is text that reads as human to a human. When it does, detectors usually agree.

## What you get back

Every result has the same parts, so you can see exactly what was done:

1. **The rewritten text.**
2. **What changed.** The 5 to 8 most important edits, each with the reason. Then one line counting the smaller ones ("plus 6 smaller edits").
3. **Facts check.** The numbers, names, dates and promises from the original, each confirmed unchanged.
4. **Flags.** Anything doubtful: a claim that looks wrong, a confidential detail, missing material. Left out if there is nothing to flag.
5. **Scores.** Four checks (see "Scoring"), with any rule that failed named.
6. **Checker result.** How many banned items the script found and fixed, and which soft flags are left.
7. **Shorter version offer.** Only when the piece has enough padding to cut (see "The shorter-version check").

## Example

A made-up writer, to show the idea. Real results follow the writer's voice profile.

**Before (AI-sounding):**

> In today's fast-paced world, our new dashboard leverages cutting-edge analytics to deliver a seamless experience. It's not just a reporting tool, it's a game-changer for your team. Moreover, it reduces report time by 40%.

**After:**

> Our new dashboard cuts your team's report time by 40%. It's a reporting tool built on analytics.

**What changed:**

- Cut the stock opener "In today's fast-paced world".
- Cut "cutting-edge", "seamless experience" and "game-changer". They are adjectives with nothing specific behind them.
- Cut the "It's not just X, it's Y" formula.
- Cut "Moreover".
- Moved the one hard fact (40%) to the front.
- Kept: the new dashboard, the analytics, the reporting tool, your team, the 40%.

## The steps

1. Find the voice profile.
2. Choose a mode: Rewrite or Interview.
3. Choose the archetype (which of the writer's voices to use).
4. List the facts in the original.
5. Write.
6. Run the checker script and fix every hard hit.
7. Score the four checks. Revise anything that fails.
8. Read it aloud as the writer. Anything they wouldn't say gets plainer.
9. Run the shorter-version check.
10. Return the result in the format above.

## Step 1: Find the voice profile

Look in the skill folder for files named `voice-profile-*.md`. Ignore the template. The skill folder is the folder this SKILL.md was loaded from.

- One profile: use it.
- Several: use the one that matches the person's name, or ask which one.
- None: run the setup interview below before doing anything else.

A profile can change the rules in sets 3 and 4, and can add or allow banned words. It can never change the Facts rules.

### Setup interview (when there is no profile yet)

Say: "I don't have your voice profile yet. Setup takes about seven questions." Ask one question at a time. Accept "go with it" wherever you offer a default.

1. What do you write, and for whom? Name one to three audiences or uses. Each becomes an archetype (for example: recruiters and hiring managers, followers on a social platform, clients).
2. Paste two or three real pieces per archetype that you wrote without AI. If you have none, say so. That archetype will be marked "to be refined" and built from your description.
3. Describe each voice: tone, formal or casual, and what you would never say.
4. Which AI habits do you hate? Is anything on the default ban list in `tells.md` something you actually use?
5. How much roughness should be kept in each archetype: clean, light imperfection, or full imitation?
6. What are your spelling and dialect, your length norms for each platform, your hashtag habits, and how do you usually close a piece?
7. What must never be touched or invented (names, jargon, confidential details)?

Then copy `voice-profile-template.md`, fill it in from the answers, and save it as `voice-profile-<name>.md` in the skill folder. If you can't save there, show the finished profile and ask the person to save it there.

Never build a profile from guesses. A sample written with AI help doesn't count as a sample.

## Step 2: Choose a mode

**Rewrite (the default).** The writer gives you text. Edit it into their voice.

**Interview.** Ask the writer questions first when the draft is missing something only the writer knows. Use this test: could anyone given the same one-line request have written this text? If yes, the text has no real example, no real number behind words like "significantly", no account of what went wrong, and no real opinion. No edit can invent those. You have to ask.

Use Interview mode when:

- The writer asks for it.
- The text fails the test above and the writer is there to answer. This is the usual case for posts, newsletters, essays, bios, talk abstracts, pitch emails, landing pages, job posts and launch stories.
- There is no input at all.
- The input is raw notes or a voice-memo transcript. Build the piece from those notes, and use them as the source for the facts check.

Rewrite without asking when the text is operational (a Slack reply, a status update, a release note, a support reply) and all its facts are already there. If the draft is already mostly human, make light edits and say "this is mostly clean."

How an interview works:

- Offer first: "This is thin. Want me to interview you?" Don't switch silently. (If the writer already asked for an interview, just start.)
- Ask all 3 to 5 questions in one message, so the writer can answer with one voice memo.
- Ask for what AI can't invent: a moment they saw, a number, a name, what they actually think, what they'd tell a friend.
- Always include one question that asks for their opinion.
- Build the piece from their answers. Keep their exact phrases wherever they work. Change only the structure and the opening and closing lines.

## Step 3: Choose the archetype

Archetypes come from the profile. Each has a "use for" line. Pick one from the platform and the content. If you can't tell, ask one short question. If the writer names an archetype, use it. If the profile has only one voice, use that.

## The rules

The rules are in four sets. Each set answers one question and is scored by the check of the same name, so no rule appears twice.

| Rule set | Question it answers | Scored by |
|---|---|---|
| 1. Facts | What must stay exactly as it is? | Check 1 |
| 2. Tells | What gets removed? | Check 2 |
| 3. Rhythm and craft | How do the sentences sound? | Check 3 |
| 4. Voice and fit | Does it suit this writer, reader and place? | Check 4 |

If two rules clash, Facts win, then Tells, then the voice profile, then the rest.

### Rule set 1: Facts (what must stay)

Before writing, list every number, name, date, price, quote, condition, promise, benefit and caveat in the source. After writing, check the result sentence by sentence.

- **Keep every item,** with the same value and the same level of certainty.
- **Keep the speaker.** "I" stays "I" and "we" stays "we".
- **Keep the strength of each word.** "Can help" must not become "will". "Might" must not become "would". "Little" must not become "no". A proposal must not become a promise. Don't add "only", "every", "always" or "guaranteed".
- **Don't spell out what the draft only hinted at.**
- **Add nothing new.** No fact, example, story, reason, benefit, opinion or detail the writer didn't give. Even small human touches (a specific number, a name, a small admission, an aside) must come from the writer's text or interview answers. If they are missing, ask.
- **Keep what is already human.** Specific details, unusual word choices, opinions, asides, humour, doubt and mixed feelings stay. So do the terms the reader would type or search for.
- **If a claim looks wrong or unsupported,** leave it as written and flag it.

### Rule set 2: Tells (what gets removed)

These are hard bans unless marked soft. They must never appear in the output. If the checker finds one, fix it and run the checker again. The ban applies to the output, not to the writer's past writing.

**Punctuation**

- Em dashes and en dashes, anywhere. Use a period, comma, colon, brackets or a new sentence instead. Only a profile with `dashes=ok` can relax this.
- Semicolons, unless the profile says they are only a soft flag (or fine) for that voice.

**Banned words and phrases.** The full lists are in `tells.md`: AI favourite words ("delve", "tapestry", "leverage", "seamless"), stock transitions ("moreover", "thus"), stock openers ("In today's fast-paced world"), stock closers ("In conclusion"), filler ("it's worth noting") and LinkedIn clichés ("thrilled to announce"). A profile can add words, or allow some for that writer.

**Formula sentences**

- "It's not just X, it's Y." Also "It's not X, it's Y" and "X isn't about Y, it's about Z."
- "Whether you're a X or a Y."
- A question answered straight away: "Why does this matter? Because..." Just say the point.

**Signposting and hedging.** Say the thing. Cut lines where the writer announces the point instead of making it: "Here's the thing:", "Here's what matters:", "Let me be clear:", "Let's break it down." Also cut the one-line colon reveal ("The best part: it learns.") and a count announced before a list ("Three things changed:"). The point should simply be the next sentence.

**Closers that restate or fish for engagement.** "The bottom line?", "Key takeaway:", "And that's why X is the future.", "What do you think?", "Thoughts?". End on the last concrete thing, or on one line of what the writer concludes. One exception: if the profile says a voice ends with a specific, real question to the reader, you may use one. The generic closers above stay banned.

**Stacked quotable lines.** "Less clicking. More building." "Automation executes. Agency decides." The budget is at most one crafted, quotable line per piece, and zero is fine. Experienced writers use zero to one, even in long posts. Turn the rest into plain statements that keep the fact. A profile may exempt a voice.

**Empty claims**

- An adjective with nothing specific behind it ("significant", "seamless", "powerful", "robust", "game-changing"). Use the number, name or mechanism the source gives, or cut the adjective. Never supply a number the source lacks.
- Inflated importance ("a pivotal moment", "a testament to", "reshaping the landscape", "the future looks bright"). Keep the fact and drop the importance.
- Vague authority ("experts agree", "studies show", "many companies"). Name who, if the source does. Otherwise cut it or limit it ("in our tests").
- Jargon that only performs expertise. The reader's working terms stay.

**Soft flags.** These are fine once or twice. A cluster of them fails the Tells check.

- A tidy summary sentence ending every paragraph.
- Bold text in the middle of a sentence.
- Motivational-poster endings.
- Weaker words that real people use too, but AI overuses ("however", "nuanced", "ensure", "Honestly,"). The full list is in `tells.md`.
- "journey", "ecosystem" and "landscape". These are ordinary terms in many fields ("customer journey", "competitive landscape", "marketplace ecosystem"). Keep them when they are the precise term. Cut them when they are decorative ("a journey of growth", "navigating the landscape").

### Rule set 3: Rhythm and craft (how the sentences sound)

1. **Vary sentence length hard.** Mix one-word or very short sentences with long ones. Break any even rhythm.
2. **Use contractions** ("it's", "don't"), except in formal documents such as policies and contracts. The checker flags uncontracted forms ("do not", "it is").
3. **Use fragments on purpose,** for emphasis. Like this.
4. **Start some sentences with And, But, So or Because.** Plain connectors are fine when they do real work.
5. **Pick plain words over stiff ones.** Use "use", "help", "start", "need", "fix", "send". "The recommended approach is X" becomes "Do X". "Serves as" becomes "is". "Perform an evaluation of" becomes "evaluate". "Posits", "contends" and "asserts" become "says" or "writes". The test: would you say this to a smart friend over coffee? Don't use the first word an AI would pick.
6. **Break up lists of three.** Mix pairs and single items.
7. **Make each sentence lean on the one before:** cause, contrast, example, consequence. Test: if you can shuffle the sentences without losing meaning, the text is a stack of facts, not an argument. Don't fake it by adding connector words.
8. **Use one word for one thing.** If "the tool", "the platform" and "the solution" are the same thing, pick one. Readers wonder whether they are different.
9. **Meet the profile's sentence-length range,** and don't start three sentences in a row with the same word.

### Rule set 4: Voice and fit (does it suit this writer, reader and place)

1. **Use the right archetype** for the platform and reader.
2. **Speak to the reader as "you"** where the genre does. Show ownership: "I'll send the tracking number", not "Tracking details will be provided".
3. **Say warmth once, plainly,** where the genre is personal (a thank-you, an apology, an invitation). One exclamation mark is fine where a person would really exclaim.
4. **Add no personality.** No "Honestly,", no forced slang, no "lol", no joke the writer didn't make, no chatty rhetorical question, no invented "I remember when" story.
5. **Allow at most one idiom or slangy phrase per paragraph,** unless the profile relaxes it. A cluster of them reads as a humanizing pass.
6. **Use the profile's spelling and dialect.** Keep the writer's regional phrasing and cultural references. Don't smooth them into neutral global English.
7. **Match the profile's roughness level** (clean, light, or full on request only). Never plant typos or a lowercase costume.
8. **Follow the profile for hashtags.** Keep the writer's own. Add only as many as the profile allows.
9. **Keep the length in range:** within about 15% of the original, and inside the profile's norms for the platform. Cutting padding is fine. Never cut a fact, the voice, or warmth the genre needs. In Interview mode, length follows the platform and the writer's answers.
10. **Follow the genre.** Keep its conventions (a list in a release note, a sign-off in a letter) and use the notes below.
11. **Match the profile's samples:** their openings, punctuation and tone.
12. **Read it aloud as the writer.** It should sound like something they would say.

Genre notes:

- **Slack, DM, WhatsApp or a thread reply:** give the answer or the ask first. Cut background the reader already has. One to four sentences is often enough, and it doesn't need a formal build-up.
- **Cold email:** one specific reason for writing to this person, taken from the source, and one ask.
- **Social post:** line 1 is the most concrete thing in the post.
- **Release note or product update:** what changed, who it is for, what to do, with the numbers.
- **Docs, PRDs, policies:** plain and precise. Keep the structure. Hedge only where the uncertainty is real.

## Checking your work

### The checker script

Save the draft to a temporary file outside the skill folder. Then run:

`python3 <skill folder>/check.py <draft file> --profile <skill folder>/voice-profile-<name>.md --archetype <archetype name>`

The script reads `tells.md` from its own folder, and reads the writer's personal bans, allowances and rhythm settings from the profile. It reports hard-ban hits, soft flags and rhythm numbers. It exits with code 1 if it finds any hard hit.

Treat every hit as a candidate. Check each one, because some will be false alarms (for example, "harness" can mean a climbing harness). The script can't tell a figurative word from a literal one, so use judgement. A word may stay only if it is the precise choice and no plainer word fits.

If code can't run in this session, go through the draft by hand against `tells.md` and the profile's lists.

### Scoring

Score every rewrite on four checks. Each check scores one rule set.

- **Check 1, Facts: pass or fail.** Every rule in Rule set 1 must hold. One fail fails the whole result.
- **Check 2, Tells: pass or fail.** Zero hard-ban hits, and no cluster of soft flags. The script does most of this.
- **Check 3, Rhythm and craft: needs 85% to pass.** Score every rule in Rule set 3.
- **Check 4, Voice and fit: needs 85% to pass.** Score every rule in Rule set 4.

How to work out a percentage: mark each rule pass or fail, leave out any rule that doesn't apply (for example, there are no hashtags in the piece), and divide the passes by the rules that apply. With 7 to 13 rules applying you can miss one. With 6 or fewer you can miss none. Name every rule that failed in the Scores line, for example "Rhythm 89% (missed: repeated openers)".

If any check fails, revise and score again before returning the result.

This is Claude's own marking, not an independent test. The script measures only the numbers, and even those only print "OK" or "CHECK".

### The shorter-version check

Run this every time, silently. Skip it for pieces under about 100 words.

1. Cover one paragraph at a time and read the rest. Would the reader miss a fact, a promise, a decision or the writer's point? If not, that paragraph is a cut candidate.
2. The usual candidates are:
   - an opening that states the point in general terms before the piece shows it
   - lines any similar piece would have (a general moral, a second thank-you)
   - a part that repeats another part (keep the stronger one)
   - a second argument that could stand alone
3. Never offer to cut the proof or the stakes: the examples, the numbers, the promises, or a disclosure that makes the reader trust the piece.
4. Add up the word counts of the candidates. If they come to about a quarter of the text or more, offer the shorter version and let the writer decide. Otherwise say nothing.

## Never

- Never claim the text "passes AI detection". The skill can't run a detector. Say the draft was checked against the writer's rules.
- Never translate.

## Words used in this skill

- **Writer:** the person whose voice you are writing in.
- **Source:** whatever the writer gave you: a draft, notes or a voice-memo transcript.
- **Voice profile:** a file describing one person's voices, samples, spelling, lengths and personal rules.
- **Archetype:** one of a writer's voices. A person may write one way for recruiters and another way for social media. Each way is an archetype.
- **Hard ban:** something that must never appear in the output.
- **Soft flag:** something that is fine once or twice but a problem when several pile up.
- **Burstiness:** how much sentence length varies. A mix of short, medium and long sentences scores high. Sentences all the same length score low and read like a machine.
- **Fragment:** a sentence without a full verb or subject, used on purpose.
