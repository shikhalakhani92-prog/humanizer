#!/usr/bin/env python3
"""check.py: finds AI-sounding patterns in a draft.

What it does
    Reads a draft and prints three things:
    1. Hard-ban hits. Things that must never appear (dashes, banned words, stock phrases).
    2. Soft flags. Things that are fine once or twice but a problem in a cluster.
    3. Rhythm numbers. Sentence length, variety and similar. These are hints only.

How to run it
    python3 check.py draft.txt --profile voice-profile-NAME.md --archetype NAME

    --profile and --archetype are optional. Without a profile, only the universal
    bans in tells.md apply, and no rhythm targets are checked.

Where the rules come from
    tells.md                the banned words and phrases for everyone
    the voice profile       extra bans, allowed words, and the settings for each voice
                            (the profile's CHECKER section, explained in the template)

Result
    Exit code 1 if there is any hard-ban hit, otherwise 0.
    Every hit is a candidate. A person decides if it is a real problem
    (for example, "harness" can also mean a climbing harness).
"""
import argparse
import pathlib
import re
import statistics
import sys

# The folder this script lives in. tells.md is expected to sit next to it.
HERE = pathlib.Path(__file__).resolve().parent

# The dash characters are written as numbers so this file contains no dashes itself.
EM_DASH = chr(0x2014)
EN_DASH = chr(0x2013)

# The sections of tells.md (and of a profile) that hold word lists.
LIST_SECTIONS = ["HARD WORDS", "HARD PHRASES", "HARD CLOSERS", "HARD LINKEDIN", "SOFT WORDS"]

# Sentence patterns that are hard to list as plain words. Each is a label and a regular expression.
CONSTRUCTIONS = [
    ("'it's not just X, it's Y'",
     r"\b(?:it's|it is|this is|that's) not (?:just|only|merely) [^.?!\n]{1,80}?[,;:]? ?(?:it's|it is|but|this is|that's)\b"),
    ("'it's not X, it's Y'",
     r"\b(?:it's|it is|this is|that's) not (?!just |only |merely )[^.?!\n]{1,60}?, (?:it's|it is|this is|that's)\b"),
    ("'X isn't about Y, it's about Z'",
     r"\b(?:isn't|aren't|is not|are not) (?:just |only |merely )?about [^.?!\n]{1,60}?, (?:it's|it is|they're|they are|this is) about\b"),
    ("'whether you're a X or a Y'",
     r"\bwhether you(?:'re| are) an? [^.?!\n]{1,40} or an? "),
    ("question answered at once",
     r"\?\s+(?:because|the answer|simply put|put simply)\b"),
    ("question answered at once",
     r"\bwhy (?:does|should|is|do) (?:this|it|that|any of this) matter\?"),
    ("count announced before a list",
     r"\b(?:two|three|four|five|six|seven|eight|nine|ten|\d+) (?:key |main |simple |big |important |major )?"
     r"(?:things|ways|reasons|steps|ideas|lessons|points|tips|mistakes|changes|takeaways|rules|questions)\b[^.?!\n]{0,30}:"),
]

# Full forms that a person would usually contract ("do not" becomes "don't").
UNCONTRACTED = re.compile(
    r"\b(?:do not|does not|did not|is not|are not|was not|cannot|can not|will not|"
    r"would not|should not|have not|has not|I am|you are|we are|they are|I will|"
    r"we will|you will|I have|we have)\b",
    re.I,
)

# Three or more emoji in a row.
EMOJI_RUN = re.compile(r"(?:[\U0001F300-\U0001FAFF☀-➿]\s*){3,}")
WORD = re.compile(r"[A-Za-z0-9'\-]+")


def normalise(text):
    """Turn curly quotes into straight ones so matching is simple."""
    return (text.replace("’", "'").replace("‘", "'")
                .replace("“", '"').replace("”", '"'))


def load_sections(path):
    """Read a file made of '## NAME' sections. Return {NAME: [lowercase lines]}.

    Lines starting with # are comments and are skipped.
    """
    sections = {}
    current = None
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("## "):
            current = line[3:].strip().upper()
            sections.setdefault(current, [])
            continue
        if line.startswith("#"):
            continue
        if current is not None:
            sections[current].append(normalise(line.lower()))
    return sections


def parse_checker(lines):
    """Read the profile's CHECKER lines.

    Returns (global settings, {voice name: settings}).
    """
    glob, arch = {}, {}
    for line in lines:
        head, sep, rest = line.partition(":")
        if not sep:
            continue
        head = head.strip()
        parts = [p.strip() for p in rest.split("|")]
        if head == "global":
            for kv in parts:
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    glob[k.strip()] = v.strip()
        elif head == "archetype" and parts and parts[0]:
            name = parts[0]
            settings = {}
            for kv in parts[1:]:
                if "=" in kv:
                    k, v = kv.split("=", 1)
                    settings[k.strip()] = v.strip()
            arch[name] = settings
    return glob, arch


def get(settings, key, cast, default=None):
    """Read one setting as a number. Return the default if it is missing or not a number."""
    try:
        return cast(settings[key])
    except (KeyError, ValueError):
        return default


def forms(word):
    """Return a word and its common other forms, so 'leverage' also catches 'leveraged'."""
    out = {word}
    if word.endswith("e"):
        out |= {word + "s", word + "d", word[:-1] + "ing"}
    elif word.endswith("y") and len(word) > 1 and word[-2] not in "aeiou":
        out |= {word[:-1] + "ies", word[:-1] + "ied", word + "ing"}
    elif word.endswith(("s", "x", "z", "ch", "sh")):
        out |= {word + "es", word + "ed", word + "ing"}
    else:
        out |= {word + "s", word + "ed", word + "ing"}
    out.add(word + "ly")
    return out


def word_pattern(entry):
    """Match a listed word and its other forms as whole words.

    'leverage' catches 'leveraged' and 'leveraging' but not a longer, unrelated word.
    An entry with a space in it is matched as an exact phrase.
    """
    if " " in entry:
        return phrase_pattern(entry)
    variants = sorted(forms(entry), key=len, reverse=True)
    return re.compile(r"(?<!\w)(?:" + "|".join(re.escape(v) for v in variants) + r")(?!\w)", re.I)


def phrase_pattern(entry):
    """Match the exact phrase, not as part of a longer word."""
    return re.compile(r"(?<!\w)" + re.escape(entry) + r"(?!\w)", re.I)


def scan_lines(lines, pattern, label, bucket):
    """Look for a pattern on every line and record each match with its line number."""
    for n, line in enumerate(lines, 1):
        for m in pattern.finditer(line):
            bucket.append(f"line {n}: {label}: '{m.group(0)}'")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("file")
    ap.add_argument("--profile", default=None)
    ap.add_argument("--archetype", default=None)
    ap.add_argument("--tells", default=str(HERE / "tells.md"))
    args = ap.parse_args()

    raw = pathlib.Path(args.file).read_text(encoding="utf-8")
    text = normalise(raw)
    lines = text.splitlines()

    # Load the universal lists.
    tells = load_sections(pathlib.Path(args.tells))
    for sec in LIST_SECTIONS:
        tells.setdefault(sec, [])

    # Add the profile's extra entries, remove the ones it allows, and read its settings.
    glob, arch = {}, {}
    notes = []
    if args.profile:
        prof = load_sections(pathlib.Path(args.profile))
        allow = set(prof.get("ALLOW", []))
        for sec in LIST_SECTIONS:
            merged = tells[sec] + prof.get(sec, [])
            tells[sec] = [e for e in merged if e not in allow]
        glob, arch = parse_checker(prof.get("CHECKER", []))

    name = (args.archetype or "").lower()
    settings = arch.get(name, {})
    if args.profile and name and name not in arch:
        notes.append(f"no CHECKER settings for archetype '{name}', using defaults")

    hard, soft = [], []

    # Dashes are a hard ban unless the profile says dashes=ok.
    if glob.get("dashes", "hard") == "hard":
        for n, line in enumerate(lines, 1):
            if EM_DASH in line:
                hard.append(f"line {n}: em dash")
            if EN_DASH in line:
                hard.append(f"line {n}: en dash")

    # Semicolons: hard by default, or soft, or ignored, depending on the voice.
    semi = settings.get("semicolons", "hard")
    if semi in ("hard", "soft"):
        for n, line in enumerate(lines, 1):
            if ";" in line:
                (hard if semi == "hard" else soft).append(f"line {n}: semicolon")

    # Banned words and phrases from the lists.
    for e in tells["HARD WORDS"]:
        scan_lines(lines, word_pattern(e), "banned word", hard)
    for e in tells["HARD PHRASES"]:
        scan_lines(lines, phrase_pattern(e), "banned phrase", hard)
    for e in tells["HARD CLOSERS"]:
        scan_lines(lines, phrase_pattern(e), "generic closer", hard)
    for e in tells["HARD LINKEDIN"]:
        scan_lines(lines, phrase_pattern(e), "LinkedIn cliche", hard)
    for e in tells["SOFT WORDS"]:
        scan_lines(lines, word_pattern(e), "soft flag", soft)

    # Sentence patterns.
    for label, rx in CONSTRUCTIONS:
        scan_lines(lines, re.compile(rx, re.I), label, hard)

    # Other soft signals.
    for n, line in enumerate(lines, 1):
        if "**" in line:
            soft.append(f"line {n}: bold markup (check for mid-sentence bolding)")
        if EMOJI_RUN.search(line):
            soft.append(f"line {n}: emoji string")
    hashtags = re.findall(r"#\w+", text)
    if len(hashtags) > 4:
        soft.append(f"{len(hashtags)} hashtags (check they are the writer's own, not added)")
    if settings.get("contractions", "expect") == "expect":
        unc = UNCONTRACTED.findall(text)
        if unc:
            soft.append(f"{len(unc)} uncontracted forms (fine in formal documents only), e.g. '{unc[0]}'")

    # Rhythm numbers. These are hints, they never fail a draft.
    clean = re.sub(r"https?://\S+|#\w+|\*\*", "", text)
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", clean) if s.strip()]
    lens = [len(WORD.findall(s)) for s in sents]
    lens = [x for x in lens if x > 0]
    rhythm = []
    if lens:
        mean = statistics.mean(lens)
        burst = statistics.pstdev(lens) / mean if mean else 0
        rhythm.append(f"{len(lens)} sentences, mean {mean:.1f} words, burstiness {burst:.2f}")

        band = settings.get("band")
        if band:
            try:
                lo, hi = (int(x) for x in band.split("-"))
                need = get(settings, "band_share", float, 0.6)
                share = sum(lo <= x <= hi for x in lens) / len(lens)
                rhythm.append(f"{share:.0%} in the {lo}-{hi} word band (target {need:.0%}+) -> "
                              f"{'OK' if share >= need else 'CHECK'}")
            except ValueError:
                rhythm.append(f"bad band setting '{band}'")
        if settings.get("one_word") == "no":
            n1 = sum(x == 1 for x in lens)
            rhythm.append(f"one-word sentences: {n1} (none allowed) -> {'OK' if n1 == 0 else 'CHECK'}")
        mx = get(settings, "max_sentence", int)
        if mx:
            rhythm.append(f"longest {max(lens)} words (max {mx}) -> {'OK' if max(lens) <= mx else 'CHECK'}")
        bmin = get(settings, "burstiness", float)
        if bmin is not None and len(lens) >= 4:
            rhythm.append(f"burstiness {burst:.2f} (target >= {bmin}) -> {'OK' if burst >= bmin else 'CHECK'}")
        short = get(settings, "short_under", int)
        if short:
            need = get(settings, "short_share", float, 0.7)
            share = sum(x < short for x in lens) / len(lens)
            rhythm.append(f"{share:.0%} under {short} words (target {need:.0%}+) -> "
                          f"{'OK' if share >= need else 'CHECK'}")
        mc = get(settings, "max_chars", int)
        if mc:
            chars = len(raw.strip())
            rhythm.append(f"{chars} characters (max {mc}) -> {'OK' if chars <= mc else 'CHECK'}")

        # Three sentences in a row starting with the same word.
        openers = [WORD.findall(s)[0].lower() for s in sents if WORD.findall(s)]
        for i in range(len(openers) - 2):
            if openers[i] == openers[i + 1] == openers[i + 2]:
                rhythm.append(f"three sentences in a row start with '{openers[i]}' -> CHECK")
                break
    else:
        rhythm.append("no sentences found")

    # Print the report.
    for note in notes:
        print("NOTE: " + note)
    print(f"HARD-BAN HITS: {len(hard)}")
    for h in hard:
        print("  " + h)
    print(f"SOFT FLAGS: {len(soft)}")
    for s in soft:
        print("  " + s)
    print("RHYTHM (hints only):")
    for r in rhythm:
        print("  " + r)
    print("RESULT: " + ("FAIL (fix hard hits and run again)" if hard else "PASS (zero hard hits)"))
    sys.exit(1 if hard else 0)


if __name__ == "__main__":
    main()
