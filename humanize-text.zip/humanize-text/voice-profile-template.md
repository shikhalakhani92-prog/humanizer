---
name: voice-profile-template
person: NAME
---
# Voice profile: NAME

This is a blank voice profile. It describes how one person writes, so the skill can write in that voice.

How to use it:
1. Copy this file and name the copy `voice-profile-<name>.md`, for example `voice-profile-priya.md`.
2. Replace every instruction in [square brackets] with the person's real answers, then delete the brackets.
3. Save the copy in the skill folder, next to SKILL.md.

## Who writes and who reads
[One or two lines: who you are as a writer, and who reads what you write.]

## Archetypes
[An archetype is one of your voices. List one block per voice, for example "Professional" and "Social". Copy the block below for each one.]

### ARCHETYPE NAME
- Use for: [the platforms, readers and formats this voice is for]
- Tone and register: [for example crisp and warm and formal, or casual and opinionated]
- Voice markers to keep: [contractions, humour, short punchy sentences, local phrasing, anything that makes it you]
- Never: [things this voice would not say]
- Sentence rhythm: [for example mostly 12 to 25 words, or a mix of 1 to 30]
- Imperfection: [clean, light, or full imitation on request only]
- Length: [per platform]
- Closers and hashtags: [how pieces usually end, which hashtags are yours, how many may be added]
- Real sample: [paste a piece written without AI, or write "none"]
- Status: [grounded, or to be refined (no real sample yet)]

## Spelling and dialect
[For example British or American spelling. Regional phrases and cultural references to keep exactly as they are.]

## Stretch targets
[Writers whose voice you admire but don't want copied line for line, and the moves to borrow. Leave blank if none.]

## Never touch or invent
[Names, jargon and confidential details the skill must flag or leave alone.]

## Personal bans and allowances
[Plain-language notes on words you want banned, or words on the default ban list that you actually use. The lists below are the part the checker script reads.]

## HARD WORDS
# Extra words that must never appear. One per line, lowercase.
# Write the full correct word, for example "leverage". The checker also catches its other forms.

## HARD PHRASES
# Extra phrases that must never appear. One per line, lowercase.

## SOFT WORDS
# Extra words to warn about when they pile up. One per line, lowercase.

## ALLOW
# Words or phrases from tells.md that this writer genuinely uses and is fine with.
# Write each exactly as it appears in tells.md, one per line.

## How the checker settings work
The CHECKER section below sets how strict the checker script is for each voice. It has one line for each voice and one global line.

- `global: dashes=hard` means em and en dashes fail the draft. Use `dashes=ok` to allow them.
- `semicolons=hard` means a semicolon fails the draft. `semicolons=soft` means it only warns. `semicolons=ok` means it is ignored. The default is hard.
- `band=12-25` with `band_share=0.6` means at least 60% of sentences should be 12 to 25 words long.
- `one_word=no` means one-word sentences are not allowed.
- `max_sentence=30` means no sentence longer than 30 words.
- `burstiness=0.45` means sentence length must vary at least that much. Below it, the rhythm is too even. It is only measured when the text has 4 or more sentences.
- `short_under=15` with `short_share=0.7` means at least 70% of sentences should be under 15 words.
- `max_chars=280` means the whole text must fit in 280 characters.
- `contractions=expect` means the checker warns about forms like "do not" and "it is". Use `contractions=ignore` to switch the warning off.

Only the dash and semicolon settings can fail a draft. The rhythm settings print "OK" or "CHECK" as a hint. The voice name on each line must be lowercase and match the name Claude uses.

## CHECKER
# Remove the # at the start of the lines below and edit them. One line per voice.
# global: dashes=hard
# archetype: name | semicolons=hard | band=12-25 | band_share=0.6 | one_word=no | max_sentence=30 | burstiness=0.45 | short_under=15 | short_share=0.7 | max_chars=280 | contractions=expect
