# Humanize Text

A skill for Claude that rewrites AI-sounding text so it reads like you wrote it. It keeps every fact and changes only how the text sounds.

## What it does

- Rewrites a draft in your own voice, using a short file that describes how you write (your voice profile).
- Keeps every number, name, date and promise exactly as it was. It never adds facts.
- Removes the habits that make text read as AI: stock phrases, favourite AI words, dashes, neat little morals, sentences that are all the same length.
- If your draft is thin and generic, it interviews you first, asks 3 to 5 questions, and builds the piece from your answers in your words.
- Shows its work every time, so you can see what changed and why.

## What it does not do

- It doesn't promise to beat AI detectors. Detectors are unreliable, and no rewrite can guarantee a result. The aim is text that reads as human to a person.
- It doesn't translate.
- It doesn't invent details to fill a gap. If something is missing, it asks you.

## What's in the folder

| File | What it is |
|---|---|
| `SKILL.md` | The instructions Claude follows. It holds the rules, not anyone's voice. |
| `voice-profile-<name>.md` | One file per person, describing how they write. |
| `voice-profile-template.md` | A blank profile to copy when you add a new person. |
| `tells.md` | The list of banned words and phrases. |
| `check.py` | A small script that scans a draft for banned items and measures rhythm. |
| `README.md` | This file, for people. Claude doesn't need it. |

Keep all the files together in one folder. The skill needs them all.

## How to install (Claude app)

1. Zip the `humanize-text` folder so the folder itself is the top level of the zip.
2. Upload the zip in Claude's settings, then switch the skill on under Capabilities. The exact button may look different depending on your version.
3. Skills need a paid plan, and code execution must be on. Without code execution the skill still works, but it checks the draft by hand instead of running `check.py`.

## How to use it

Paste your text and say what it is for. For example:

- "Humanize this LinkedIn post."
- "Make this email to a recruiter sound like me."
- "Here's a voice-memo transcript. Turn it into a LinkedIn post."
- "I need a post about [topic] but I've got nothing written. Interview me."

Claude works out which of your voices to use from the platform and the content. If it can't tell, it asks one short question.

## What you get back

1. The rewritten text.
2. What changed: the 5 to 8 most important edits, each with the reason.
3. A facts check, confirming every number, name and promise is unchanged.
4. Flags: anything doubtful, such as a claim that looks wrong.
5. Scores on four checks.
6. The result of the checker script.
7. An offer of a shorter version, only when the piece has enough padding to cut.

## What the skill bans, and why

AI text has habits that readers notice. These are the ones the skill removes.

| What | Examples | Why |
|---|---|---|
| Dashes | the long dash and the medium dash | The most obvious sign of AI writing. A comma, a full stop or a new sentence does the same job. |
| Semicolons | ; | AI uses them far more than people do in casual writing. A profile can relax this for one voice. |
| AI favourite words | delve, tapestry, leverage, seamless, robust | AI picks these far more often than people do. |
| Stock phrases | "In today's fast-paced world", "Let's dive in", "In conclusion" | They fill space without saying anything. |
| Formula sentences | "It's not just X, it's Y", "Why does this matter? Because..." | AI reuses the same few sentence shapes. |
| Engagement closers | "Thoughts?", "What do you think?" | They could end any post. A specific, real question is still fine. |
| Empty claims | "seamless" or "powerful" with no detail behind it | An adjective with no fact behind it tells the reader nothing. |

Some words are only soft flags, because real people use them too: "however", "nuanced", "journey", "ecosystem", "landscape". The skill keeps them when they are the precise term and cuts them when they are decoration.

The full word lists are in `tells.md`.

## How the scoring works

- **Facts:** pass or fail. If any fact changed, the whole result fails.
- **Tells:** pass or fail. No banned words, dashes or stock phrases allowed.
- **Rhythm and craft:** needs 85% to pass. It covers sentence variety, contractions, fragments, word choices and flow.
- **Voice and fit:** needs 85% to pass. It covers whether it sounds like you, the right tone for the platform, spelling and length.

Anything that fails is revised before you see it. The marking is done by Claude, so treat it as a careful checklist, not an independent test.

## Setting it up for a new person

You don't need to write a profile by hand. If Claude can't find a profile, it asks about seven questions, one at a time: who you write for, samples of your own writing, how each voice sounds, which AI habits you hate, how much roughness to keep, your spelling and lengths, and what must never be touched. It then saves your profile.

Use samples you wrote without AI. A profile built on AI-written samples teaches the skill the wrong voice.

## Changing the rules

- To ban or allow words for one person, edit their voice profile.
- To change the lists for everyone, edit `tells.md`.
- To change how the skill behaves, edit `SKILL.md`.

Keep the section names in `tells.md` and in the profiles exactly as they are, because the script looks for them.
