# TELLS: the words and phrases this skill removes, and why

# A "tell" is something that gives away AI writing. This file lists them.
#
# There are two kinds:
#   HARD = never allowed. If the checker finds one, it must be fixed.
#   SOFT = fine once or twice. Several together are a problem.
#
# Why they are banned: AI picks the most likely word every time, so the same words and
# phrases show up again and again. People use them far less often. Readers notice, and so
# do detectors.
#
# How to read the lists:
# - Every word is written in its correct spelling, one per line, in lowercase.
# - The checker also catches the other forms of a word. "leverage" also catches
#   "leveraged" and "leveraging". You don't need to list them.
# - A phrase is matched exactly, including any punctuation. "picture this:" only matches
#   when a colon follows.
#
# How to change the lists:
# - Add a line to ban something. Delete a line to allow it.
# - Keep the "## " headings exactly as they are. The checker looks for them.
# - A writer can add to these lists, or allow an entry, in their own voice profile.
#
# Some bans can't be listed as words, so the checker handles them separately:
# dashes, semicolons, and sentence shapes like "It's not X, it's Y". SKILL.md explains them.

## HARD WORDS
# NEVER ALLOWED: single words that AI overuses.

# Verbs. Why: they make plain actions sound grand ("leverage" just means "use").
delve
leverage
utilize
utilise
navigate
harness
foster
facilitate
streamline
empower
elevate
underscore
spearhead
unlock
unleash
revolutionize
revolutionise

# Hype adjectives. Why: they sound impressive but say nothing specific.
cutting-edge
game-changer
game changer
revolutionary
transformative
seamless
robust
comprehensive
multifaceted
pivotal
paramount
state-of-the-art
next-level
myriad
plethora
meticulous

# Grand-sounding nouns. Why: they swap a plain fact for a big metaphor.
tapestry
realm
testament
cornerstone
beacon

# Stock linking words. Why: they make a post sound like a school essay.
moreover
furthermore
additionally
consequently
thus
hence
notably
indeed

## HARD PHRASES
# NEVER ALLOWED: stock phrases AI overuses.

# Filler. Why: they add words without adding meaning. Say the thing instead.
treasure trove
it's worth noting
it is worth noting
it's important to note
it is important to note
it's important to understand
at its core
in essence
when it comes to
when it comes down to it
the world of
a testament to
plays a crucial role
play a crucial role
plays a vital role
play a vital role
plays a key role
play a key role
navigate the complexities
in a world where
needless to say
that being said

# Stock openers. Why: they delay the point. Delete them and start with the point.
in today's fast-paced world
in the digital age
as we all know
in this section we'll
in this section, we'll
in this article we'll
in this article, we'll
let's dive in
picture this:
imagine a world where

# Stock closers. Why: they repeat what the piece already said. End on the last concrete thing.
in conclusion
to sum up
all in all
at the end of the day
the bottom line is
the bottom line?
by doing so, you'll be well on your way to
that's the real win

# Pause-and-point lines. Why: the writer announces the point instead of making it.
here's what matters
let me be clear
let's break it down
key takeaway
the best part:

## HARD CLOSERS
# NEVER ALLOWED: generic endings that fish for replies.
# Why: they could end any post, so they say nothing about this one. A specific, real
# question to the reader is still fine (SKILL.md explains when).
thoughts?
agree?
what do you think?
what are your thoughts?
so what does this mean?
drop a comment
let me know in the comments

## HARD LINKEDIN
# NEVER ALLOWED: LinkedIn clichés.
# Why: nearly every announcement post uses them, so they tell the reader nothing about you.
thrilled to announce
excited to announce
i'm excited to share
i am excited to share
hope this finds you well
let's unpack
here's the thing

## SOFT WORDS
# ALLOWED IN MODERATION: fine once or twice, a problem when several pile up.

# Weaker linking words. Why: they are everywhere in AI text, but people use them too.
however
importantly
ultimately
essentially
fundamentally
nevertheless
nonetheless
accordingly
subsequently

# Words people use too, but AI overuses.
nuanced
intricate
vibrant
curated
holistic
synergy
bespoke
boast

# Ordinary terms in many fields: "customer journey", "competitive landscape", "marketplace
# ecosystem". Keep them when they are the precise term. Cut them when they are decoration
# ("a journey of growth", "navigating the landscape").
journey
ecosystem
landscape

# Other soft flags. Why: they sound stiff or add personality that wasn't there.
serves as a
stands as a
ensure
enable
honestly
quick heads-up
on a happier note
not bad
